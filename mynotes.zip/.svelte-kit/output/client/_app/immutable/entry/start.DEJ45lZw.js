import{l as o,c as r}from"../chunks/D4eFE5zq.js";export{o as load_css,r as start};
