
// this file is generated — do not edit it


declare module "svelte/elements" {
	export interface HTMLAttributes<T> {
		'data-sveltekit-keepfocus'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-noscroll'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-preload-code'?:
			| true
			| ''
			| 'eager'
			| 'viewport'
			| 'hover'
			| 'tap'
			| 'off'
			| undefined
			| null;
		'data-sveltekit-preload-data'?: true | '' | 'hover' | 'tap' | 'off' | undefined | null;
		'data-sveltekit-reload'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-replacestate'?: true | '' | 'off' | undefined | null;
	}
}

export {};


declare module "$app/types" {
	type MatcherParam<M> = M extends (param : string) => param is (infer U extends string) ? U : string;

	export interface AppTypes {
		RouteId(): "/" | "/about" | "/admin" | "/admin/login" | "/admin/logout" | "/admin/posts" | "/admin/posts/new" | "/admin/posts/[id]" | "/[slug]";
		RouteParams(): {
			"/admin/posts/[id]": { id: string };
			"/[slug]": { slug: string }
		};
		LayoutParams(): {
			"/": { id?: string; slug?: string };
			"/about": Record<string, never>;
			"/admin": { id?: string };
			"/admin/login": Record<string, never>;
			"/admin/logout": Record<string, never>;
			"/admin/posts": { id?: string };
			"/admin/posts/new": Record<string, never>;
			"/admin/posts/[id]": { id: string };
			"/[slug]": { slug: string }
		};
		Pathname(): "/" | "/about" | "/admin" | "/admin/login" | "/admin/logout" | "/admin/posts/new" | `/admin/posts/${string}` & {} | `/${string}` & {};
		ResolvedPathname(): `${"" | `/${string}`}${ReturnType<AppTypes['Pathname']>}`;
		Asset(): string & {};
	}
}