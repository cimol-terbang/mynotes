import { redirect } from "@sveltejs/kit";
import { a as authService } from "../chunks/auth.service.js";
import { b as building } from "../chunks/environment.js";
const PROTECTED_ROUTES = /^\/admin(?!\/login)/;
async function handle({ event, resolve }) {
  if (building) return resolve(event);
  if (PROTECTED_ROUTES.test(event.url.pathname)) {
    const sessionId = event.cookies.get("session_id");
    const valid = await authService.validateSession(sessionId);
    if (!valid) {
      throw redirect(302, "/admin/login");
    }
  }
  return resolve(event);
}
export {
  handle
};
