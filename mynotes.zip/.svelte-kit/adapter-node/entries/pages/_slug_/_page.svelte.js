import { c as create_ssr_component, e as escape, f as each, b as add_attribute, v as validate_component } from "../../../chunks/ssr.js";
import { C as CATEGORY_ICONS, a as CATEGORY_LABELS } from "../../../chunks/constants.js";
import { r as renderMarkdown } from "../../../chunks/markdown.js";
import "@sveltejs/kit/internal";
import "../../../chunks/exports.js";
import "../../../chunks/utils.js";
import "@sveltejs/kit/internal/server";
import "../../../chunks/state.svelte.js";
const PostContent = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let html;
  let { content } = $$props;
  if ($$props.content === void 0 && $$bindings.content && content !== void 0) $$bindings.content(content);
  html = renderMarkdown(content);
  return `<div class="prose prose-gray dark:prose-invert max-w-none"><!-- HTML_TAG_START -->${html}<!-- HTML_TAG_END --></div>`;
});
function formatDate$1(dateStr) {
  return new Date(dateStr).toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  });
}
const CommentList = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { comments = [] } = $$props;
  if ($$props.comments === void 0 && $$bindings.comments && comments !== void 0) $$bindings.comments(comments);
  return `<section aria-label="Comments"><h2 class="font-serif text-base sm:text-lg font-semibold text-ink-900 dark:text-night-100 mb-5 sm:mb-6 flex items-center gap-2"><span class="text-accent dark:text-violet-DEFAULT text-sm" aria-hidden="true" data-svelte-h="svelte-dzssz3">◈</span> ${escape(comments.length === 0 ? "No comments yet" : `${comments.length} ${comments.length === 1 ? "Comment" : "Comments"}`)}</h2> ${comments.length === 0 ? `<p class="text-ink-400 dark:text-night-500 text-sm italic pl-5" data-svelte-h="svelte-40pxj0">Be the first to leave a thought.</p>` : `<ul class="space-y-5 sm:space-y-6">${each(comments, (comment) => {
    return `<li class="relative pl-4 border-l-2 border-ink-100 dark:border-violet-dark/30 hover:border-accent dark:hover:border-violet-DEFAULT/50 transition-colors"><div class="flex flex-wrap items-center gap-2 mb-1.5"><span class="text-sm font-medium text-ink-800 dark:text-night-200">${escape(comment.authorName)}</span> <span class="text-ink-200 dark:text-night-700" aria-hidden="true" data-svelte-h="svelte-1fztssi">·</span> <time class="text-xs text-ink-400 dark:text-night-500"${add_attribute("datetime", comment.createdAt, 0)}>${escape(formatDate$1(comment.createdAt))} </time></div> <p class="text-ink-600 dark:text-night-300 text-sm leading-relaxed whitespace-pre-wrap">${escape(comment.content)}</p> </li>`;
  })}</ul>`}</section>`;
});
const CommentForm = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { form } = $$props;
  let { onCommentAdded = () => {
  } } = $$props;
  let nameValue = "";
  if ($$props.form === void 0 && $$bindings.form && form !== void 0) $$bindings.form(form);
  if ($$props.onCommentAdded === void 0 && $$bindings.onCommentAdded && onCommentAdded !== void 0) $$bindings.onCommentAdded(onCommentAdded);
  return `<section aria-label="Leave a comment"><h3 class="font-serif text-base sm:text-lg font-semibold text-ink-900 dark:text-night-100 mb-4 sm:mb-5 flex items-center gap-2" data-svelte-h="svelte-1cujjbh"><span class="text-accent dark:text-violet-DEFAULT text-sm" aria-hidden="true">✦</span>
    Leave a Comment</h3> ${form?.error ? `<div class="mb-4 px-4 py-3 rounded-xl bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800/50"><p class="text-sm text-red-600 dark:text-red-400" role="alert">${escape(form.error)}</p></div>` : ``} <form method="POST" action="?/comment" class="space-y-4"><div><label for="authorName" class="block text-xs font-medium uppercase tracking-wide mb-1.5 text-ink-500 dark:text-night-400" data-svelte-h="svelte-kq3qr5">Name <span class="normal-case font-normal text-ink-400 dark:text-night-600">(optional)</span></label> <input id="authorName" name="authorName" type="text" placeholder="Anonymous" class="w-full px-4 py-2.5 rounded-xl text-sm border border-ink-200 dark:border-violet-dark/30 bg-white dark:bg-night-950/60 text-ink-900 dark:text-night-100 placeholder:text-ink-300 dark:placeholder:text-night-600 focus:outline-none focus:ring-2 focus:ring-accent/30 dark:focus:ring-violet-DEFAULT/30 focus:border-accent dark:focus:border-violet-DEFAULT/60 transition-all"${add_attribute("value", nameValue, 0)}></div> <div><label for="content" class="block text-xs font-medium uppercase tracking-wide mb-1.5 text-ink-500 dark:text-night-400" data-svelte-h="svelte-1vb4har">Comment <span class="text-accent dark:text-violet-DEFAULT">*</span></label> <textarea id="content" name="content" required rows="4" placeholder="Share your thoughts..." class="w-full px-4 py-2.5 rounded-xl text-sm border border-ink-200 dark:border-violet-dark/30 bg-white dark:bg-night-950/60 text-ink-900 dark:text-night-100 placeholder:text-ink-300 dark:placeholder:text-night-600 focus:outline-none focus:ring-2 focus:ring-accent/30 dark:focus:ring-violet-DEFAULT/30 focus:border-accent dark:focus:border-violet-DEFAULT/60 transition-all resize-y">${escape("")}</textarea></div> <button type="submit" ${""} class="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium bg-ink-900 text-ink-50 hover:bg-ink-700 dark:bg-violet-glow dark:text-white dark:hover:bg-violet-dark dark:shadow-[0_0_20px_rgba(139,92,246,0.3)] dark:hover:shadow-[0_0_28px_rgba(139,92,246,0.45)] transition-all disabled:opacity-50">${`Post Comment`}</button></form></section>`;
});
function formatDate(dateStr) {
  return new Date(dateStr).toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric"
  });
}
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  let { form } = $$props;
  let comments = data.comments;
  function handleCommentAdded(newComment) {
    comments = [...comments, newComment];
  }
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  if ($$props.form === void 0 && $$bindings.form && form !== void 0) $$bindings.form(form);
  return `${$$result.head += `<!-- HEAD_svelte-4jkcye_START -->${$$result.title = `<title>${escape(data.post.title)} — My Notes</title>`, ""}<!-- HEAD_svelte-4jkcye_END -->`, ""}  <div class="mb-8 sm:mb-10" data-svelte-h="svelte-gd2sgb"><a href="/" class="inline-flex items-center gap-1.5 text-xs font-medium text-ink-400 dark:text-night-500 hover:text-ink-700 dark:hover:text-violet-light transition-colors group"><svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" class="group-hover:-translate-x-0.5 transition-transform" aria-hidden="true"><path d="M10 4L6 8l4 4"></path></svg>
    All writing</a></div> <article><header class="mb-8 sm:mb-10"> <div class="flex flex-wrap items-center gap-2 mb-4"><a href="${"/?category=" + escape(data.post.category, true)}" class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium border bg-ink-100 text-ink-600 border-ink-200 dark:bg-violet-dark/20 dark:text-violet-light dark:border-violet-dark/30 hover:opacity-80 transition-opacity"><span aria-hidden="true">${escape(CATEGORY_ICONS[data.post.category])}</span> ${escape(CATEGORY_LABELS[data.post.category])}</a> <span class="text-ink-200 dark:text-night-700" aria-hidden="true" data-svelte-h="svelte-1fztssi">·</span> <time class="text-xs text-ink-400 dark:text-night-500"${add_attribute("datetime", data.post.createdAt, 0)}>${escape(formatDate(data.post.createdAt))}</time></div>  <h1 class="font-serif text-2xl sm:text-3xl md:text-4xl font-semibold leading-tight text-ink-900 dark:text-night-50 dark:text-glow text-balance mb-6">${escape(data.post.title)}</h1>  <div class="flex items-center gap-3" data-svelte-h="svelte-1u54et"><div class="h-px flex-1 bg-gradient-to-r from-transparent via-ink-200 dark:via-violet-dark/30 to-transparent"></div> <span class="text-accent dark:text-violet-DEFAULT text-xs tracking-widest" aria-hidden="true">✦</span> <div class="h-px flex-1 bg-gradient-to-r from-transparent via-ink-200 dark:via-violet-dark/30 to-transparent"></div></div></header> ${validate_component(PostContent, "PostContent").$$render($$result, { content: data.post.content }, {}, {})}  <div class="flex justify-center mt-10 sm:mt-12 mb-4" data-svelte-h="svelte-1ex4uyx"><span class="text-ink-300 dark:text-violet-dark/60 text-sm tracking-[0.4em]" aria-hidden="true">· · ·</span></div></article>  <div class="mt-10 sm:mt-12 pt-8 sm:pt-10 border-t border-ink-200/60 dark:border-violet-dark/20 space-y-10 sm:space-y-12">${validate_component(CommentList, "CommentList").$$render($$result, { comments }, {}, {})} ${validate_component(CommentForm, "CommentForm").$$render($$result, { form, onCommentAdded: handleCommentAdded }, {}, {})}</div>`;
});
export {
  Page as default
};
