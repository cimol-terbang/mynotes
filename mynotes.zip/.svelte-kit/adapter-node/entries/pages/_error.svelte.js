import { c as create_ssr_component, d as subscribe, e as escape } from "../../chunks/ssr.js";
import { p as page } from "../../chunks/stores.js";
const Error = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $page, $$unsubscribe_page;
  $$unsubscribe_page = subscribe(page, (value) => $page = value);
  $$unsubscribe_page();
  return `${$$result.head += `<!-- HEAD_svelte-m6psn_START -->${$$result.title = `<title>${escape($page.status)} — My Notes</title>`, ""}<!-- HEAD_svelte-m6psn_END -->`, ""} <div class="text-center py-20"><p class="font-serif text-7xl font-semibold text-ink-200 dark:text-ink-800 mb-4">${escape($page.status)}</p> <h1 class="font-serif text-2xl font-semibold mb-2 text-ink-900 dark:text-ink-100">${$page.status === 404 ? `Page not found.` : `Something went wrong.`}</h1> <p class="text-ink-400 dark:text-ink-600 text-sm mb-8">${escape($page.error?.message ?? "")}</p> <a href="/" class="text-accent hover:underline text-sm" data-svelte-h="svelte-1a6jk9t">← Back to home</a></div>`;
});
export {
  Error as default
};
