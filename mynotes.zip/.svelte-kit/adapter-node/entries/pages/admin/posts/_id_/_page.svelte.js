import { c as create_ssr_component, e as escape, b as add_attribute, f as each, v as validate_component } from "../../../../../chunks/ssr.js";
import "@sveltejs/kit/internal";
import "../../../../../chunks/exports.js";
import "../../../../../chunks/utils.js";
import "@sveltejs/kit/internal/server";
import "../../../../../chunks/state.svelte.js";
import { M as MarkdownEditor } from "../../../../../chunks/MarkdownEditor.js";
import { a as CATEGORY_LABELS, b as CATEGORIES } from "../../../../../chunks/constants.js";
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  let { form } = $$props;
  let contentValue = form?.content ?? data.post.content;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  if ($$props.form === void 0 && $$bindings.form && form !== void 0) $$bindings.form(form);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    $$rendered = `${$$result.head += `<!-- HEAD_svelte-1uhky2e_START -->${$$result.title = `<title>Edit: ${escape(data.post.title)} — Admin</title>`, ""}<!-- HEAD_svelte-1uhky2e_END -->`, ""} <div class="flex items-center gap-3 mb-8" data-svelte-h="svelte-1f986h4"><a href="/admin" class="text-sm text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200">← Kembali</a> <h1 class="text-2xl font-bold text-gray-900 dark:text-gray-100">Edit Tulisan</h1></div> ${form?.error ? `<div class="mb-6 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-md"><p class="text-sm text-red-600 dark:text-red-400">${escape(form.error)}</p></div>` : ``} <form method="POST" action="?/update"><div class="space-y-6"><div><label for="title" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1" data-svelte-h="svelte-iasyes">Judul</label> <input id="title" name="title" type="text" required${add_attribute("value", form?.title ?? data.post.title, 0)} class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500"></div> <div><label for="category" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1" data-svelte-h="svelte-7f2ak">Kategori</label> <select id="category" name="category" required class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500">${each(CATEGORIES, (cat) => {
      return `<option${add_attribute("value", cat, 0)} ${(form?.category ?? data.post.category) === cat ? "selected" : ""}>${escape(CATEGORY_LABELS[cat])}</option>`;
    })}</select></div> ${validate_component(MarkdownEditor, "MarkdownEditor").$$render(
      $$result,
      {
        name: "content",
        label: "Konten",
        value: contentValue
      },
      {
        value: ($$value) => {
          contentValue = $$value;
          $$settled = false;
        }
      },
      {}
    )} <div class="flex items-center justify-between"><div class="flex gap-3"><button type="submit" ${""} class="px-6 py-2 bg-gray-900 dark:bg-gray-100 text-white dark:text-gray-900 font-medium rounded-md hover:opacity-80 transition-opacity disabled:opacity-50">${escape("Simpan Perubahan")}</button> <a href="/admin" class="px-6 py-2 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 font-medium rounded-md hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors" data-svelte-h="svelte-1kht7oy">Batal</a></div> <button type="button" class="px-4 py-2 text-red-600 dark:text-red-400 border border-red-300 dark:border-red-700 rounded-md hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors text-sm" data-svelte-h="svelte-5t62c3">Hapus Tulisan</button></div></div></form> ${``}`;
  } while (!$$settled);
  return $$rendered;
});
export {
  Page as default
};
