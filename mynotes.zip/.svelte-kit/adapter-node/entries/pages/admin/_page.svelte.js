import { c as create_ssr_component, d as subscribe, e as escape, f as each } from "../../../chunks/ssr.js";
import { p as page } from "../../../chunks/stores.js";
import { a as CATEGORY_LABELS } from "../../../chunks/constants.js";
function formatDate(dateStr) {
  return new Date(dateStr).toLocaleDateString("id-ID", {
    year: "numeric",
    month: "short",
    day: "numeric"
  });
}
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let successMsg;
  let $page, $$unsubscribe_page;
  $$unsubscribe_page = subscribe(page, (value) => $page = value);
  let { data } = $$props;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  successMsg = $page.url.searchParams.get("success");
  $$unsubscribe_page();
  return `${$$result.head += `<!-- HEAD_svelte-gab6aw_START -->${$$result.title = `<title>Admin — Tulisanku</title>`, ""}<!-- HEAD_svelte-gab6aw_END -->`, ""} <div class="flex items-center justify-between mb-8" data-svelte-h="svelte-10jh5ul"><h1 class="text-2xl font-bold text-gray-900 dark:text-gray-100">Semua Tulisan</h1> <a href="/admin/posts/new" class="px-4 py-2 bg-gray-900 dark:bg-gray-100 text-white dark:text-gray-900 text-sm font-medium rounded-md hover:opacity-80 transition-opacity">+ Tulisan Baru</a></div> ${successMsg ? `<div class="mb-6 p-3 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-md" data-svelte-h="svelte-166qbz6"><p class="text-sm text-green-700 dark:text-green-400">Postingan berhasil disimpan.</p></div>` : ``} ${data.error ? `<p class="text-red-600 dark:text-red-400 text-sm mb-4">${escape(data.error)}</p>` : ``} ${data.posts.length === 0 ? `<p class="text-gray-500 dark:text-gray-400 text-center py-12" data-svelte-h="svelte-4yzgyf">Belum ada tulisan.</p>` : `<div class="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden"><table class="w-full text-sm"><thead class="bg-gray-50 dark:bg-gray-700 border-b border-gray-200 dark:border-gray-600" data-svelte-h="svelte-7pmfwe"><tr><th class="text-left px-4 py-3 font-medium text-gray-700 dark:text-gray-300">Judul</th> <th class="text-left px-4 py-3 font-medium text-gray-700 dark:text-gray-300 hidden sm:table-cell">Kategori</th> <th class="text-left px-4 py-3 font-medium text-gray-700 dark:text-gray-300 hidden md:table-cell">Tanggal</th> <th class="px-4 py-3"></th></tr></thead> <tbody class="divide-y divide-gray-100 dark:divide-gray-700">${each(data.posts, (post) => {
    return `<tr class="hover:bg-gray-50 dark:hover:bg-gray-750 transition-colors"><td class="px-4 py-3 font-medium text-gray-900 dark:text-gray-100"><a href="${"/" + escape(post.slug, true)}" target="_blank" class="hover:text-blue-600 dark:hover:text-blue-400">${escape(post.title)} </a></td> <td class="px-4 py-3 text-gray-500 dark:text-gray-400 hidden sm:table-cell">${escape(CATEGORY_LABELS[post.category])}</td> <td class="px-4 py-3 text-gray-500 dark:text-gray-400 hidden md:table-cell">${escape(formatDate(post.createdAt))}</td> <td class="px-4 py-3 text-right"><a href="${"/admin/posts/" + escape(post._id, true)}" class="text-blue-600 dark:text-blue-400 hover:underline">Edit
              </a></td> </tr>`;
  })}</tbody></table></div>`}`;
});
export {
  Page as default
};
