import { redirect } from "@sveltejs/kit";
import { a as authService } from "../../../../chunks/auth.service.js";
const actions = {
  default: async (event) => {
    await authService.destroySession(event);
    throw redirect(302, "/admin/login");
  }
};
export {
  actions
};
