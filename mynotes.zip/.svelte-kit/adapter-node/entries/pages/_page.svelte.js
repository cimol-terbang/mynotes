import { c as create_ssr_component, e as escape, f as each, b as add_attribute, v as validate_component } from "../../chunks/ssr.js";
import { C as CATEGORY_ICONS, a as CATEGORY_LABELS, b as CATEGORIES } from "../../chunks/constants.js";
const CategoryNav = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { activeCategory = null } = $$props;
  if ($$props.activeCategory === void 0 && $$bindings.activeCategory && activeCategory !== void 0) $$bindings.activeCategory(activeCategory);
  return `<nav class="flex flex-wrap gap-2 mb-8 sm:mb-10" aria-label="Filter by category"><a href="/" class="${"inline-flex items-center gap-1.5 px-3 sm:px-4 min-h-[40px] sm:min-h-[44px] rounded-full text-xs font-medium tracking-wide uppercase transition-all " + escape(
    activeCategory === null ? "bg-ink-900 text-ink-50 shadow-sm dark:bg-violet-glow dark:text-white dark:shadow-[0_0_16px_rgba(139,92,246,0.4)]" : "bg-ink-100 text-ink-500 hover:bg-ink-200 dark:bg-night-950/60 dark:text-night-400 dark:border dark:border-violet-dark/20 dark:hover:border-violet-DEFAULT/40 dark:hover:text-violet-light",
    true
  )}">All</a> ${each(CATEGORIES, (cat) => {
    return `<a href="${"/?category=" + escape(cat, true)}" class="${"inline-flex items-center gap-1.5 px-3 sm:px-4 min-h-[40px] sm:min-h-[44px] rounded-full text-xs font-medium tracking-wide uppercase transition-all " + escape(
      activeCategory === cat ? "bg-ink-900 text-ink-50 shadow-sm dark:bg-violet-glow dark:text-white dark:shadow-[0_0_16px_rgba(139,92,246,0.4)]" : "bg-ink-100 text-ink-500 hover:bg-ink-200 dark:bg-night-950/60 dark:text-night-400 dark:border dark:border-violet-dark/20 dark:hover:border-violet-DEFAULT/40 dark:hover:text-violet-light",
      true
    )}"><span class="text-accent dark:text-violet-DEFAULT text-[10px]" aria-hidden="true">${escape(CATEGORY_ICONS[cat])}</span> ${escape(CATEGORY_LABELS[cat])} </a>`;
  })}</nav>`;
});
function formatDate(date) {
  return new Date(date).toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric"
  });
}
const PostCard = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { post } = $$props;
  const categoryColors = {
    essay: "dark:text-violet-light dark:bg-violet-dark/20 dark:border-violet-dark/30",
    poetry: "dark:text-pink-300 dark:bg-pink-900/20 dark:border-pink-800/30",
    story: "dark:text-sky-300 dark:bg-sky-900/20 dark:border-sky-800/30"
  };
  if ($$props.post === void 0 && $$bindings.post && post !== void 0) $$bindings.post(post);
  return `<article class="group py-6 sm:py-8"><a href="${"/" + escape(post.slug, true)}" class="block rounded-xl p-4 sm:p-5 -mx-4 sm:-mx-5 hover:bg-ink-100/60 dark:hover:bg-violet-dark/10 dark:hover:shadow-[0_0_30px_rgba(139,92,246,0.08)] transition-all duration-300"> <div class="flex flex-wrap items-center gap-2 mb-3"><span class="${"inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-medium border bg-ink-100 text-ink-500 border-ink-200 " + escape(categoryColors[post.category], true)}"><span aria-hidden="true">${escape(CATEGORY_ICONS[post.category])}</span> ${escape(CATEGORY_LABELS[post.category])}</span> <span class="text-ink-200 dark:text-night-700" aria-hidden="true" data-svelte-h="svelte-1fztssi">·</span> <time class="text-xs text-ink-400 dark:text-night-500"${add_attribute("datetime", post.createdAt, 0)}>${escape(formatDate(post.createdAt))}</time></div>  <h2 class="font-serif text-lg sm:text-xl font-semibold text-ink-900 dark:text-night-100 mb-2 leading-snug group-hover:text-accent dark:group-hover:text-violet-light transition-colors text-balance">${escape(post.title)}</h2>  <p class="text-ink-500 dark:text-night-400 text-sm leading-relaxed line-clamp-2 mb-3">${escape(post.excerpt)}</p>  <span class="inline-flex items-center gap-1.5 text-xs font-medium text-accent dark:text-violet-DEFAULT opacity-0 group-hover:opacity-100 translate-x-0 group-hover:translate-x-1 transition-all duration-200" data-svelte-h="svelte-apc5bd">Read more
      <svg width="12" height="12" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" fill="none"></path></svg></span></a></article>`;
});
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  return `${$$result.head += `<!-- HEAD_svelte-1vfkocf_START -->${$$result.title = `<title>My Notes — A Personal Writing Space</title>`, ""}<!-- HEAD_svelte-1vfkocf_END -->`, ""}  ${!data.activeCategory ? `<div class="mb-10 sm:mb-14 pb-10 sm:pb-14 border-b border-ink-200/60 dark:border-violet-dark/20 relative"> <div aria-hidden="true" class="absolute -top-2 right-0 text-4xl sm:text-5xl text-accent/8 dark:text-violet-DEFAULT/8 font-serif select-none leading-none" data-svelte-h="svelte-1y0jzo1">﷽</div> ${data.ayah ? `<div class="relative"> <span aria-hidden="true" class="absolute -top-6 -left-1 sm:-left-3 text-6xl sm:text-8xl text-accent/15 dark:text-violet-DEFAULT/20 font-serif leading-none select-none" data-svelte-h="svelte-1mjs886">&quot;</span> <blockquote class="pl-3 sm:pl-5"><p class="font-serif text-xl sm:text-2xl md:text-3xl font-medium leading-snug text-ink-800 dark:text-night-100 dark:text-glow text-balance mb-4 sm:mb-5">${escape(data.ayah.text)}</p> <footer class="flex items-center gap-2 text-sm text-ink-400 dark:text-night-400"><span class="text-accent dark:text-violet-DEFAULT text-xs" data-svelte-h="svelte-1pqgb35">◈</span> <cite class="not-italic">${escape(data.ayah.surah)} ${escape(data.ayah.surahNumber)}:${escape(data.ayah.ayahNumber)}</cite></footer></blockquote></div>` : ``}  <div aria-hidden="true" class="flex items-center gap-3 mt-8 sm:mt-10" data-svelte-h="svelte-1o8tpll"><div class="h-px flex-1 bg-gradient-to-r from-transparent via-ink-200 dark:via-violet-dark/30 to-transparent"></div> <span class="text-accent/50 dark:text-violet-DEFAULT/50 text-xs tracking-[0.3em]">✦ ✦ ✦</span> <div class="h-px flex-1 bg-gradient-to-r from-transparent via-ink-200 dark:via-violet-dark/30 to-transparent"></div></div></div>` : ``} ${validate_component(CategoryNav, "CategoryNav").$$render($$result, { activeCategory: data.activeCategory }, {}, {})} ${data.error ? `<div class="py-12 sm:py-16 text-center"><div class="inline-flex flex-col items-center gap-3"><span class="text-3xl" aria-hidden="true" data-svelte-h="svelte-1e327yq">🌙</span> <p class="text-ink-400 dark:text-night-500 text-sm">${escape(data.error)}</p></div></div>` : `${data.posts.length === 0 ? `<div class="py-12 sm:py-16 text-center" data-svelte-h="svelte-10mc74r"><div class="inline-flex flex-col items-center gap-3"><span class="text-3xl" aria-hidden="true">✍️</span> <p class="text-ink-400 dark:text-night-500 text-sm italic">Nothing here yet.</p></div></div>` : `<div class="divide-y divide-ink-100 dark:divide-violet-dark/15">${each(data.posts, (post) => {
    return `${validate_component(PostCard, "PostCard").$$render($$result, { post }, {}, {})}`;
  })}</div>`}`}`;
});
export {
  Page as default
};
