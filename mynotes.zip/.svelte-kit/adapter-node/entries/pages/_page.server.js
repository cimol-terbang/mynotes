import { p as postService } from "../../chunks/post.service.js";
const TOTAL_AYAHS = 6236;
async function fetchRandomAyah() {
  try {
    const num = Math.floor(Math.random() * TOTAL_AYAHS) + 1;
    const res = await fetch(`https://api.alquran.cloud/v1/ayah/${num}/en.asad`);
    if (!res.ok) throw new Error("API error");
    const json = await res.json();
    const ayah = json.data;
    return {
      text: ayah.text,
      surah: ayah.surah.englishName,
      surahNumber: ayah.surah.number,
      ayahNumber: ayah.numberInSurah
    };
  } catch {
    return {
      text: "Indeed, with hardship will be ease.",
      surah: "Ash-Sharh",
      surahNumber: 94,
      ayahNumber: 6
    };
  }
}
async function load({ url }) {
  const category = url.searchParams.get("category") || void 0;
  const validCategories = ["essay", "poetry", "story"];
  const activeCategory = validCategories.includes(category) ? category : null;
  const [postsResult, ayah] = await Promise.allSettled([
    postService.listPosts(activeCategory ?? void 0),
    fetchRandomAyah()
  ]);
  const posts = postsResult.status === "fulfilled" ? postsResult.value : [];
  const postError = postsResult.status === "rejected" ? "Layanan sedang tidak tersedia. Silakan coba lagi nanti." : null;
  if (postsResult.status === "rejected") {
    console.error("Failed to load posts:", postsResult.reason);
  }
  return {
    posts,
    activeCategory,
    error: postError,
    ayah: ayah.status === "fulfilled" ? ayah.value : null
  };
}
export {
  load
};
