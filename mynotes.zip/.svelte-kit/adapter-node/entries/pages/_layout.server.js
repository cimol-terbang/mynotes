import { a as authService } from "../../chunks/auth.service.js";
async function load({ cookies }) {
  const sessionId = cookies.get("session_id");
  const isAdmin = await authService.validateSession(sessionId);
  return { isAdmin };
}
export {
  load
};
