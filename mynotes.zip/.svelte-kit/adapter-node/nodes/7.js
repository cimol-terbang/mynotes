import * as server from '../entries/pages/admin/logout/_page.server.js';

export const index = 7;
export { server };
export const server_id = "src/routes/admin/logout/+page.server.js";
export const imports = [];
export const stylesheets = [];
export const fonts = [];
