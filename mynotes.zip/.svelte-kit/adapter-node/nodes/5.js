import * as server from '../entries/pages/admin/_page.server.js';

export const index = 5;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/admin/_page.svelte.js')).default;
export { server };
export const server_id = "src/routes/admin/+page.server.js";
export const imports = ["_app/immutable/nodes/5.B3fC_w11.js","_app/immutable/chunks/CC1d5ZRU.js","_app/immutable/chunks/WtjTZm3P.js","_app/immutable/chunks/C4ZzPQtR.js","_app/immutable/chunks/cdneNUbj.js","_app/immutable/chunks/D4eFE5zq.js"];
export const stylesheets = [];
export const fonts = [];
