import * as server from '../entries/pages/admin/posts/_id_/_page.server.js';

export const index = 9;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/admin/posts/_id_/_page.svelte.js')).default;
export { server };
export const server_id = "src/routes/admin/posts/[id]/+page.server.js";
export const imports = ["_app/immutable/nodes/9.De_k76NB.js","_app/immutable/chunks/CC1d5ZRU.js","_app/immutable/chunks/WtjTZm3P.js","_app/immutable/chunks/C4ZzPQtR.js","_app/immutable/chunks/LPErpuMy.js","_app/immutable/chunks/D4eFE5zq.js","_app/immutable/chunks/ExzjweBr.js","_app/immutable/chunks/Lg7ywK9-.js"];
export const stylesheets = [];
export const fonts = [];
