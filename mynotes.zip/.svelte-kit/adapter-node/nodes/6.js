import * as server from '../entries/pages/admin/login/_page.server.js';

export const index = 6;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/admin/login/_page.svelte.js')).default;
export { server };
export const server_id = "src/routes/admin/login/+page.server.js";
export const imports = ["_app/immutable/nodes/6.BpDKhpnE.js","_app/immutable/chunks/CC1d5ZRU.js","_app/immutable/chunks/WtjTZm3P.js","_app/immutable/chunks/LPErpuMy.js","_app/immutable/chunks/D4eFE5zq.js"];
export const stylesheets = [];
export const fonts = [];
