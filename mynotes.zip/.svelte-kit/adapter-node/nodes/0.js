import * as server from '../entries/pages/_layout.server.js';

export const index = 0;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_layout.svelte.js')).default;
export { server };
export const server_id = "src/routes/+layout.server.js";
export const imports = ["_app/immutable/nodes/0.B31T-Geq.js","_app/immutable/chunks/CC1d5ZRU.js","_app/immutable/chunks/WtjTZm3P.js"];
export const stylesheets = ["_app/immutable/assets/0.DW1W9u22.css"];
export const fonts = [];
