import * as server from '../entries/pages/_slug_/_page.server.js';

export const index = 10;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_slug_/_page.svelte.js')).default;
export { server };
export const server_id = "src/routes/[slug]/+page.server.js";
export const imports = ["_app/immutable/nodes/10.C3i14KI4.js","_app/immutable/chunks/CC1d5ZRU.js","_app/immutable/chunks/WtjTZm3P.js","_app/immutable/chunks/C4ZzPQtR.js","_app/immutable/chunks/Lg7ywK9-.js","_app/immutable/chunks/LPErpuMy.js","_app/immutable/chunks/D4eFE5zq.js"];
export const stylesheets = [];
export const fonts = [];
