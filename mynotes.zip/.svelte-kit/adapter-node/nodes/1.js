

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.CeQCxhva.js","_app/immutable/chunks/CC1d5ZRU.js","_app/immutable/chunks/WtjTZm3P.js","_app/immutable/chunks/cdneNUbj.js","_app/immutable/chunks/D4eFE5zq.js"];
export const stylesheets = [];
export const fonts = [];
