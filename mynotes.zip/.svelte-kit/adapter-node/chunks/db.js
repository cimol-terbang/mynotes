import mongoose from "mongoose";
import { b as private_env } from "./shared-server.js";
async function connectDb() {
  if (mongoose.connection.readyState === 1) return;
  const uri = private_env.MONGODB_URI;
  if (!uri) throw new Error("MONGODB_URI environment variable is not set");
  await mongoose.connect(uri);
}
export {
  connectDb as c
};
