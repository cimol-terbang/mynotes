import bcrypt from "bcrypt";
import { c as connectDb } from "./db.js";
import mongoose from "mongoose";
const AdminUserSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  passwordHash: { type: String, required: true }
});
const AdminUser = mongoose.models.AdminUser || mongoose.model("AdminUser", AdminUserSchema);
const SessionSchema = new mongoose.Schema({
  _id: { type: String },
  adminId: { type: mongoose.Schema.Types.ObjectId, ref: "AdminUser", required: true },
  expiresAt: { type: Date, required: true }
});
SessionSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });
const Session = mongoose.models.Session || mongoose.model("Session", SessionSchema);
const COOKIE_NAME = "session_id";
const SESSION_DURATION_MS = 24 * 60 * 60 * 1e3;
const COOKIE_MAX_AGE = 86400;
class AuthService {
  async verifyCredentials(username, password) {
    await connectDb();
    const admin = await AdminUser.findOne({ username }).lean();
    if (!admin) return false;
    return bcrypt.compare(password, admin.passwordHash);
  }
  async createSession(event) {
    await connectDb();
    const admin = await AdminUser.findOne({}).lean();
    if (!admin) throw new Error("No admin user found");
    const sessionId = crypto.randomUUID();
    const expiresAt = new Date(Date.now() + SESSION_DURATION_MS);
    await Session.create({ _id: sessionId, adminId: admin._id, expiresAt });
    event.cookies.set(COOKIE_NAME, sessionId, {
      httpOnly: true,
      sameSite: "strict",
      maxAge: COOKIE_MAX_AGE,
      path: "/"
    });
    return sessionId;
  }
  async validateSession(sessionId) {
    if (!sessionId) return false;
    await connectDb();
    const session = await Session.findOne({
      _id: sessionId,
      expiresAt: { $gt: /* @__PURE__ */ new Date() }
    }).lean();
    return session !== null;
  }
  async destroySession(event) {
    const sessionId = event.cookies.get(COOKIE_NAME);
    if (sessionId) {
      await connectDb();
      await Session.deleteOne({ _id: sessionId });
    }
    event.cookies.delete(COOKIE_NAME, { path: "/" });
  }
}
const authService = new AuthService();
export {
  authService as a
};
