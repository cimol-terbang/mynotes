import { c as create_ssr_component, e as escape, b as add_attribute } from "./ssr.js";
import { r as renderMarkdown } from "./markdown.js";
const MarkdownEditor = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let preview;
  let { value = "" } = $$props;
  let { name = "content" } = $$props;
  let { label = "Konten" } = $$props;
  if ($$props.value === void 0 && $$bindings.value && value !== void 0) $$bindings.value(value);
  if ($$props.name === void 0 && $$bindings.name && name !== void 0) $$bindings.name(name);
  if ($$props.label === void 0 && $$bindings.label && label !== void 0) $$bindings.label(label);
  preview = renderMarkdown(value);
  return `<div><label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">${escape(label)}</label> <div class="grid grid-cols-1 md:grid-cols-2 gap-4"><div><p class="text-xs text-gray-500 dark:text-gray-400 mb-1" data-svelte-h="svelte-1wz7y77">Markdown</p> <textarea${add_attribute("name", name, 0)} rows="20" required placeholder="Tulis konten dalam format Markdown..." class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-blue-500 resize-y">${escape(value || "")}</textarea></div> <div><p class="text-xs text-gray-500 dark:text-gray-400 mb-1" data-svelte-h="svelte-dr9gs0">Pratinjau</p> <div class="prose prose-sm prose-gray dark:prose-invert max-w-none min-h-[20rem] p-3 border border-gray-200 dark:border-gray-700 rounded-md bg-gray-50 dark:bg-gray-900 overflow-auto">${preview ? `<!-- HTML_TAG_START -->${preview}<!-- HTML_TAG_END -->` : `<p class="text-gray-400 dark:text-gray-600 italic" data-svelte-h="svelte-q0as8e">Pratinjau akan muncul di sini...</p>`}</div></div></div></div>`;
});
export {
  MarkdownEditor as M
};
