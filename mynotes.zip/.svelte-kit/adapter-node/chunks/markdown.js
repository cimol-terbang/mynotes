import { marked } from "marked";
import DOMPurify from "isomorphic-dompurify";
marked.setOptions({ gfm: true, breaks: false });
function renderMarkdown(content) {
  const rawHtml = marked.parse(content, { async: false });
  return DOMPurify.sanitize(rawHtml);
}
export {
  renderMarkdown as r
};
