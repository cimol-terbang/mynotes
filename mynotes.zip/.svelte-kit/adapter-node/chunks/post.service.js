import slugify from "slugify";
import { c as connectDb } from "./db.js";
import mongoose from "mongoose";
const PostSchema = new mongoose.Schema({
  title: { type: String, required: true },
  slug: { type: String, required: true, unique: true },
  content: { type: String, required: true },
  category: { type: String, enum: ["essay", "poetry", "story"], required: true },
  excerpt: { type: String, required: true }
}, { timestamps: true });
PostSchema.index({ category: 1, createdAt: -1 });
PostSchema.index({ createdAt: -1 });
const Post = mongoose.models.Post || mongoose.model("Post", PostSchema);
function generateExcerpt(content) {
  return content.slice(0, 150);
}
function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
class PostService {
  async listPosts(category) {
    await connectDb();
    const filter = category ? { category } : {};
    const posts = await Post.find(filter).select("title slug category excerpt createdAt").sort({ createdAt: -1 }).lean();
    return posts.map((p) => ({ ...p, _id: p._id.toString() }));
  }
  async getPostBySlug(slug) {
    await connectDb();
    const post = await Post.findOne({ slug }).lean();
    return post ?? null;
  }
  async createPost({ title, content, category }) {
    await connectDb();
    const slug = await this.generateUniqueSlug(title);
    const excerpt = generateExcerpt(content);
    const post = await Post.create({ title, slug, content, category, excerpt });
    return post.toObject();
  }
  async updatePost(id, { title, content, category }) {
    await connectDb();
    const update = { updatedAt: /* @__PURE__ */ new Date() };
    if (title !== void 0) update.title = title;
    if (content !== void 0) {
      update.content = content;
      update.excerpt = generateExcerpt(content);
    }
    if (category !== void 0) update.category = category;
    const post = await Post.findByIdAndUpdate(id, { $set: update }, { new: true }).lean();
    return post ?? null;
  }
  async deletePost(id) {
    await connectDb();
    const { Comment } = await import("./Comment.js");
    const result = await Post.findByIdAndDelete(id);
    if (!result) return false;
    await Comment.deleteMany({ postId: result._id });
    return true;
  }
  async generateUniqueSlug(title) {
    await connectDb();
    const baseSlug = slugify(title, { lower: true, strict: true, trim: true });
    const existing = await Post.findOne({ slug: baseSlug }).lean();
    if (!existing) return baseSlug;
    const pattern = "^" + escapeRegex(baseSlug) + "(-\\d+)?$";
    const conflicting = await Post.find({ slug: { $regex: pattern } }).select("slug").lean();
    const existingSlugs = new Set(conflicting.map((p) => p.slug));
    let counter = 1;
    let candidate = baseSlug + "-" + counter;
    while (existingSlugs.has(candidate)) {
      counter++;
      candidate = baseSlug + "-" + counter;
    }
    return candidate;
  }
}
const postService = new PostService();
export {
  postService as p
};
