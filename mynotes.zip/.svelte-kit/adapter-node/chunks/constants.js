const CATEGORY_LABELS = {
  essay: "What I Think",
  poetry: "What I Feel",
  story: "What I Imagine"
};
const CATEGORY_ICONS = {
  essay: "✦",
  poetry: "◈",
  story: "◉"
};
const CATEGORIES = ["essay", "poetry", "story"];
export {
  CATEGORY_ICONS as C,
  CATEGORY_LABELS as a,
  CATEGORIES as b
};
