<script>
  import { renderMarkdown } from '$lib/utils/markdown.js';
  export let value = '';
  export let name = 'content';
  export let label = 'Konten';

  $: preview = renderMarkdown(value);
</script>

<div>
  <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{label}</label>
  <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
    <div>
      <p class="text-xs text-gray-500 dark:text-gray-400 mb-1">Markdown</p>
      <textarea
        {name}
        bind:value
        rows="20"
        required
        placeholder="Tulis konten dalam format Markdown..."
        class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-blue-500 resize-y"
      ></textarea>
    </div>
    <div>
      <p class="text-xs text-gray-500 dark:text-gray-400 mb-1">Pratinjau</p>
      <div class="prose prose-sm prose-gray dark:prose-invert max-w-none min-h-[20rem] p-3 border border-gray-200 dark:border-gray-700 rounded-md bg-gray-50 dark:bg-gray-900 overflow-auto">
        {#if preview}
          {@html preview}
        {:else}
          <p class="text-gray-400 dark:text-gray-600 italic">Pratinjau akan muncul di sini...</p>
        {/if}
      </div>
    </div>
  </div>
</div>
