import { fail, redirect, error } from '@sveltejs/kit';
import { postService } from '$lib/server/post.service.js';

export async function load({ params }) {
  const posts = await postService.listPosts();
  const post = posts.find(p => p._id === params.id);
  if (!post) throw error(404, 'Postingan tidak ditemukan.');

  // Get full post with content
  const fullPost = await postService.getPostBySlug(post.slug);
  if (!fullPost) throw error(404, 'Postingan tidak ditemukan.');

  return {
    post: {
      ...fullPost,
      _id: fullPost._id.toString(),
      createdAt: fullPost.createdAt.toISOString(),
      updatedAt: fullPost.updatedAt?.toISOString(),
    }
  };
}

export const actions = {
  update: async ({ request, params }) => {
    const data = await request.formData();
    const title = data.get('title')?.toString().trim() ?? '';
    const content = data.get('content')?.toString().trim() ?? '';
    const category = data.get('category')?.toString() ?? '';

    if (!title) return fail(400, { error: 'Judul tidak boleh kosong.', title, content, category });
    if (!content) return fail(400, { error: 'Konten tidak boleh kosong.', title, content, category });
    if (!['essay', 'poetry', 'story'].includes(category)) {
      return fail(400, { error: 'Kategori tidak valid.', title, content, category });
    }

    try {
      const updated = await postService.updatePost(params.id, { title, content, category });
      if (!updated) throw error(404, 'Postingan tidak ditemukan.');
      throw redirect(302, '/admin?success=updated');
    } catch (err) {
      if (err.status === 302 || err.status === 404) throw err;
      console.error('Failed to update post:', err);
      return fail(500, { error: 'Gagal menyimpan postingan. Silakan coba lagi.', title, content, category });
    }
  },

  delete: async ({ params }) => {
    try {
      await postService.deletePost(params.id);
      throw redirect(302, '/admin?success=deleted');
    } catch (err) {
      if (err.status === 302) throw err;
      console.error('Failed to delete post:', err);
      return fail(500, { error: 'Gagal menghapus postingan.' });
    }
  }
};
