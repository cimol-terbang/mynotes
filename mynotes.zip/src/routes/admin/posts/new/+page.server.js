import { fail, redirect } from '@sveltejs/kit';
import { postService } from '$lib/server/post.service.js';

export const actions = {
  default: async ({ request }) => {
    const data = await request.formData();
    const title = data.get('title')?.toString().trim() ?? '';
    const content = data.get('content')?.toString().trim() ?? '';
    const category = data.get('category')?.toString() ?? '';

    if (!title) return fail(400, { error: 'Judul tidak boleh kosong.', title, content, category });
    if (!content) return fail(400, { error: 'Konten tidak boleh kosong.', title, content, category });
    if (!['essay', 'poetry', 'story'].includes(category)) {
      return fail(400, { error: 'Kategori tidak valid.', title, content, category });
    }

    try {
      await postService.createPost({ title, content, category });
      throw redirect(302, '/admin?success=created');
    } catch (err) {
      if (err.status === 302) throw err;
      console.error('Failed to create post:', err);
      return fail(500, { error: 'Gagal menyimpan postingan. Silakan coba lagi.', title, content, category });
    }
  }
};
